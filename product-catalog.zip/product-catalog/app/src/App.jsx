import { useState, useEffect } from 'react';
import { products } from '../src/data/prodcut';
import ProductList from './components/productlist/ProductList';
import Cart from './components/cart/Cart';
import './App.css';

function App() {
  const [cart, setCart] = useState([]);

  // Optional: Load cart from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('cart');
    if (saved) setCart(JSON.parse(saved));
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product) => {
    setCart((prevCart) => {
      const existing = prevCart.find(item => item.id === product.id);
      if (existing) {
        return prevCart.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      } else {
        return [...prevCart, { ...product, quantity: 1 }];
      }
    });
  };

  const removeFromCart = (productId) => {
    setCart((prev) => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity < 1) return;
    setCart((prev) =>
      prev.map(item =>
        item.id === productId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  return (
    <div className="app">
      <div className="container">
        <h1 className="app-title">🛒 Immersive Product Catalog</h1>
        <div className="layout">
          <div className="products-section">
            <ProductList products={products} onAddToCart={addToCart} />
          </div>
          <div className="cart-section">
            <Cart
              cart={cart}
              onRemove={removeFromCart}
              onUpdateQuantity={updateQuantity}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;