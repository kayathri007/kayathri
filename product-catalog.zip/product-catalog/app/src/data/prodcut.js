export const products = [
  { id: 1, name: 'Wireless Laptop', price: 1299 },
  { id: 2, name: 'Ergonomic Mouse', price: 35 },
  { id: 3, name: 'Mechanical Keyboard', price: 120 },
  { id: 4, name: '4K Ultra Monitor', price: 399 },
  { id: 5, name: 'Noise-Canceling Headphones', price: 199 },
];