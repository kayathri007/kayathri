// src/components/Cart.jsx
export default function Cart({ cart, onRemove, onUpdateQuantity }) {
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="cart-box">
      <h2 className="cart-title">
        Cart ({cart.length} {cart.length === 1 ? 'item' : 'items'})
      </h2>

      {cart.length === 0 ? (
        <p className="cart-empty">Your cart is empty 😢</p>
      ) : (
        <>
          {cart.map((item) => (
            <div key={item.id} className="cart-item">
              <div className="cart-item-info">
                <strong>{item.name}</strong>
                <div style={{ fontSize: '0.9rem', color: '#7f8c8d' }}>
                  ${item.price} × {item.quantity}
                </div>
              </div>
              <div className="cart-controls">
                <input
                  type="number"
                  min="1"
                  value={item.quantity}
                  onChange={(e) => {
                    const val = parseInt(e.target.value);
                    if (!isNaN(val) && val >= 1) {
                      onUpdateQuantity(item.id, val);
                    }
                  }}
                  className="quantity-input"
                />
                <button
                  className="remove-btn"
                  onClick={() => onRemove(item.id)}
                >
                  ×
                </button>
              </div>
            </div>
          ))}
          <div className="total">Total: ${total.toFixed(2)}</div>
        </>
      )}
    </div>
  );
}