// src/components/ProductList.jsx
export default function ProductList({ products, onAddToCart }) {
  return (
    <div>
      <h2 className="section-title">Products</h2>
      {products.map(product => (
        <div key={product.id} className="product-card">
          <h3 className="product-name">{product.name}</h3>
          <p className="product-price">₹{product.price}</p>
          <button
            className="add-to-cart-btn"
            onClick={() => onAddToCart(product)}
          >
            Add to Cart
          </button>
        </div>
      ))}
    </div>
  );
}